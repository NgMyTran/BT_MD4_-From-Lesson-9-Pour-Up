create
    definer = root@localhost procedure DisplayCategories()
BEGIN
    SELECT * FROM category;
END;

