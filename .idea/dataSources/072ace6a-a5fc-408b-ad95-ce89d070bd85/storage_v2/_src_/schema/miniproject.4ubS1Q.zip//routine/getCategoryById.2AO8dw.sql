create
    definer = root@localhost procedure getCategoryById(IN id int)
BEGIN
    SELECT * FROM category WHERE id = id;
END;

