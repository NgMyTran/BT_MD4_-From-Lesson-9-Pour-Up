create
    definer = root@localhost procedure getBookByCategoryId(IN categoryId int)
BEGIN
    SELECT b.id, b.name, b.price, b.stock, b.totalPages, b.yearCreated, b.author, c.name AS categoryName, b.status
    FROM book b
    INNER JOIN category c ON b.category_Id = c.id
    WHERE b.category_Id = categoryId;
END;

