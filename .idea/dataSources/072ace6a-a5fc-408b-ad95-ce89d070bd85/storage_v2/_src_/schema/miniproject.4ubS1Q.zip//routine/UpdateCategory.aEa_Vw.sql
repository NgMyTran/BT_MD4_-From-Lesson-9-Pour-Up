create
    definer = root@localhost procedure UpdateCategory(IN categoryId int, IN categoryName varchar(255), IN categoryStatus bit)
BEGIN
    UPDATE category SET name = categoryName, status = categoryStatus WHERE id = categoryId;
END;

