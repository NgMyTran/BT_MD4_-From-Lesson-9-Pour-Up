create
    definer = root@localhost procedure DeleteBook(IN bookId int)
BEGIN
    UPDATE book
    SET status = FALSE
    WHERE id = bookId;
END;

