create definer = root@localhost trigger before_delete_category
    before delete
    on category
    for each row
BEGIN
    UPDATE product
    SET status = false
    WHERE category_id = OLD.category_id;
END;

