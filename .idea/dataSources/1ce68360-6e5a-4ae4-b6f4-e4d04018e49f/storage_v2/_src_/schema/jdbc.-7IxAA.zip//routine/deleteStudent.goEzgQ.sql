create
    definer = root@localhost procedure deleteStudent(IN studentId int)
BEGIN
    DELETE FROM student WHERE id = studentId;
END;

