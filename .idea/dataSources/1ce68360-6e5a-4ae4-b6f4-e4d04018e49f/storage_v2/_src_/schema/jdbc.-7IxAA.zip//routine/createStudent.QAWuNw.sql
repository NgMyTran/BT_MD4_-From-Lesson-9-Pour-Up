create
    definer = root@localhost procedure createStudent(IN fullName varchar(255), IN email varchar(255),
                                                     IN address varchar(255), IN phone varchar(15))
BEGIN
INSERT INTO student (fullName, email, address, phone, status)
VALUES (fullName, email,address,phone, true);
END;

