create
    definer = root@localhost procedure searchStudentsByName(IN studentName varchar(255))
BEGIN
    SELECT * FROM student WHERE fullName LIKE CONCAT('%', studentName, '%');
END;

