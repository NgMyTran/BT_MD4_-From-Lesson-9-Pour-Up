create
    definer = root@localhost procedure AddProduct(IN p_productName varchar(255), IN p_productPrice double,
                                                  IN p_productStock int, IN p_productImage varchar(255),
                                                  IN p_productStatus bit)
BEGIN
    INSERT INTO Products (name, price, stock, image, status)
    VALUES (p_productName, p_productPrice, p_productStock, p_productImage, p_productStatus);
END;

