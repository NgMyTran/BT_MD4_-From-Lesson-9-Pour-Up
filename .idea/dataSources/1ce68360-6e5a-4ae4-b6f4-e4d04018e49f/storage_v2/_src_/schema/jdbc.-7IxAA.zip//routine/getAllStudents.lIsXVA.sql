create
    definer = root@localhost procedure getAllStudents()
BEGIN
    SELECT * FROM student;
END;

