create
    definer = root@localhost procedure DeleteProduct(IN productId int)
BEGIN
    UPDATE Products SET status = FALSE WHERE id = productId;
END;

