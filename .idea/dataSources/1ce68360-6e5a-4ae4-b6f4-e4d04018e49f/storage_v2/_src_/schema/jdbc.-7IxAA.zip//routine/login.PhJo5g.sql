create
    definer = root@localhost procedure login(IN p_username varchar(255), IN p_password varchar(255))
BEGIN
    SELECT * FROM Account
    WHERE username = p_username AND password = p_password;
END;

