create
    definer = root@localhost procedure GetProductById(IN productId int)
BEGIN
    SELECT * FROM Products WHERE id = productId;
END;

