create
    definer = root@localhost procedure updateStudent(IN studentId int, IN studentFullName varchar(255),
                                                     IN studentEmail varchar(255), IN studentAddress varchar(255),
                                                     IN studentPhone varchar(15), IN studentStatus bit)
BEGIN
    UPDATE student
    SET fullName = studentFullName,
        email = studentEmail,
        address = studentAddress,
        phone = studentPhone,
        status = studentStatus
    WHERE id = studentId;
END;

