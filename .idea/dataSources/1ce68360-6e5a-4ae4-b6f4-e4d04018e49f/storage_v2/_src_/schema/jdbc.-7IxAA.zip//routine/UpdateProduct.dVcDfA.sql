create
    definer = root@localhost procedure UpdateProduct(IN productId int, IN productName varchar(255),
                                                     IN productPrice double, IN productStock int,
                                                     IN productImage varchar(255), IN productStatus bit)
BEGIN
    UPDATE Products
    SET name = productName,
        price = productPrice,
        stock = productStock,
        image = productImage,
        status = productStatus
    WHERE id = productId;
END;

