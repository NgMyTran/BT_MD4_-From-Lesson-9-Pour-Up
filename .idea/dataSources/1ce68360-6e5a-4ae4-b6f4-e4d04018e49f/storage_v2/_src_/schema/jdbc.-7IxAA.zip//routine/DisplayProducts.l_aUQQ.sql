create
    definer = root@localhost procedure DisplayProducts()
BEGIN
    SELECT * FROM Products;
END;

