create
    definer = root@localhost procedure insertCandidateSkills(IN p_candidate_id int, IN p_skill_id int)
BEGIN
    INSERT INTO candidate_skills (candidate_id, skill_id)
    VALUES (p_candidate_id, p_skill_id);
END;

