create
    definer = root@localhost procedure getStudentById(IN studentId int)
BEGIN
    SELECT * FROM student WHERE id = studentId;
END;

