create
    definer = root@localhost procedure DeleteCategory(IN categoryId int)
BEGIN
    IF EXISTS (SELECT 1 FROM book WHERE category_id = categoryId) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot delete category: Books are still linked to this category.';
    ELSE
        UPDATE category SET status = FALSE WHERE id = categoryId;
    END IF;
END;

