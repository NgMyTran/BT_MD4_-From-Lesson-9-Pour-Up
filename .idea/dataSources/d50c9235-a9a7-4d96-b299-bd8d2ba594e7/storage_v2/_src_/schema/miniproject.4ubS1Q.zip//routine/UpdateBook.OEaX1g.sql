create
    definer = root@localhost procedure UpdateBook(IN bookId int, IN bookCategoryId int, IN bookName varchar(255),
                                                  IN bookPrice double, IN bookStock int, IN bookTotalPages int,
                                                  IN bookYearCreated int, IN bookAuthor varchar(255), IN bookStatus bit)
BEGIN
    UPDATE book
    SET category_id = bookCategoryId,
        name = bookName,
        price = bookPrice,
        stock = bookStock,
        totalPages = bookTotalPages,
        yearCreated = bookYearCreated,
        author = bookAuthor,
        status = bookStatus
    WHERE id = bookId;
END;

