create
    definer = root@localhost procedure getBookById(IN id int)
BEGIN
    SELECT b.id, b.category_Id, b.name, b.price, b.stock, b.totalPages, b.yearCreated, b.author, c.name AS categoryName, b.status
    FROM book b
    INNER JOIN category c ON b.category_Id = c.id
    WHERE b.id = id;
END;

