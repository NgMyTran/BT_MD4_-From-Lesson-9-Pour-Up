create
    definer = root@localhost procedure DisplayBooks()
BEGIN
    SELECT * FROM book;
END;

