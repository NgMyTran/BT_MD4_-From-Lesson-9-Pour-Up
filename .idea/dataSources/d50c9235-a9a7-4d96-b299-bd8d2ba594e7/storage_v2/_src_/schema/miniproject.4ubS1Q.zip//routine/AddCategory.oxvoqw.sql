create
    definer = root@localhost procedure AddCategory(IN categoryName varchar(255), IN categoryStatus bit)
BEGIN
    INSERT INTO category (name, status) VALUES (categoryName, categoryStatus);
END;

