create
    definer = root@localhost procedure AddBook(IN bookCategoryId int, IN bookName varchar(255), IN bookPrice double,
                                               IN bookStock int, IN bookTotalPages int, IN bookYearCreated int,
                                               IN bookAuthor varchar(255), IN bookStatus bit)
BEGIN
    INSERT INTO book (category_id, name, price, stock, totalPages, yearCreated, author, status)
    VALUES (bookCategoryId, bookName, bookPrice, bookStock, bookTotalPages, bookYearCreated, bookAuthor, bookStatus);
END;

